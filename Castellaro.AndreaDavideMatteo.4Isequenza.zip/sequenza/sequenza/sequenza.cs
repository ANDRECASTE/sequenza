using System;
using System.Collections.Generic;
using System.Linq;

public static class Sequenza
{
    public static int[] N_Due { get; private set; }

    public static int[] Verifica( int N ) 
    {
        int[] array = new int[N];
        if(N==2){
            return  N_Due;
        }
        else
        {
            Console.WriteLine("ERRORE");
        }
        return new int[0];
    }
}